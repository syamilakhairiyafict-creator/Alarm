// ===================================
// TRAVEL ALARM
// ===================================

// ELEMENT HTML
const destination = document.getElementById("destination");
const radius = document.getElementById("radius");

const startButton = document.getElementById("startButton");
const stopButton = document.getElementById("stopButton");
const testButton = document.getElementById("testButton");

const statusText = document.getElementById("status");
const currentLocation = document.getElementById("currentLocation");
const distanceText = document.getElementById("distance");
const message = document.getElementById("message");

const googleMap = document.getElementById("googleMap");
const mapsButton = document.getElementById("mapsButton");

// VARIABEL
let watchID = null;
let alarmActive = false;
let audioContext = null;

// ===================================
// HITUNG JARAK HAVERSINE
// ===================================

function calculateDistance(lat1, lon1, lat2, lon2) {

    const R = 6371000;

    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLon = (lon2 - lon1) * Math.PI / 180;

    const a =
        Math.sin(dLat / 2) * Math.sin(dLat / 2) +
        Math.cos(lat1 * Math.PI / 180) *
        Math.cos(lat2 * Math.PI / 180) *
        Math.sin(dLon / 2) * Math.sin(dLon / 2);

    const c = 2 * Math.atan2(
        Math.sqrt(a),
        Math.sqrt(1 - a)
    );

    return R * c;
}

// ===================================
// CARI LOKASI DARI NAMA TEMPAT
// ===================================

async function getLocationCoordinates(placeName) {

    try {

        const response = await fetch(
            `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(placeName)}`
        );

        const data = await response.json();

        if (data.length === 0) {
            return null;
        }

        return {
            lat: parseFloat(data[0].lat),
            lon: parseFloat(data[0].lon),
            displayName: data[0].display_name
        };

    } catch (error) {

        console.error(error);
        return null;
    }
}

// ===================================
// SUARA ALARM
// ===================================

function playAlarm() {

    const AudioClass =
        window.AudioContext ||
        window.webkitAudioContext;

    if (!AudioClass) return;

    if (!audioContext) {
        audioContext = new AudioClass();
    }

    if (audioContext.state === "suspended") {
        audioContext.resume();
    }

    const oscillator =
        audioContext.createOscillator();

    const gain =
        audioContext.createGain();

    oscillator.type = "sine";
    oscillator.frequency.value = 880;

    gain.gain.setValueAtTime(
        0.5,
        audioContext.currentTime
    );

    gain.gain.exponentialRampToValueAtTime(
        0.01,
        audioContext.currentTime + 1
    );

    oscillator.connect(gain);
    gain.connect(audioContext.destination);

    oscillator.start();
    oscillator.stop(audioContext.currentTime + 1);
}

// ===================================
// TES SUARA ALARM
// ===================================

testButton.addEventListener("click", () => {

    playAlarm();

    message.textContent =
        "Tes alarm berhasil dijalankan.";
});

// ===================================
// UPDATE GOOGLE MAPS
// ===================================

function updateGoogleMaps(placeName) {

    googleMap.src =
        `https://maps.google.com/maps?q=${encodeURIComponent(placeName)}&t=k&z=15&output=embed`;

    mapsButton.href =
        `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(placeName)}`;
}

// ===================================
// MULAI PELACAKAN
// ===================================

startButton.addEventListener("click", async () => {

    const destinationName =
        destination.value.trim();

    const alarmRadius =
        Number(radius.value);

    if (!destinationName) {

        message.textContent =
            "Masukkan lokasi tujuan.";

        return;
    }

    message.textContent =
        "Mencari lokasi tujuan...";

    const locationData =
        await getLocationCoordinates(
            destinationName
        );

    if (!locationData) {

        message.textContent =
            "Lokasi tidak ditemukan.";

        return;
    }

    const targetLat =
        locationData.lat;

    const targetLon =
        locationData.lon;

    updateGoogleMaps(destinationName);

    if (!navigator.geolocation) {

        message.textContent =
            "Browser tidak mendukung GPS.";

        return;
    }

    if (!window.isSecureContext) {

        message.textContent =
            "Gunakan HTTPS atau localhost.";

        return;
    }

    if (watchID !== null) {

        navigator.geolocation.clearWatch(
            watchID
        );
    }

    alarmActive = false;

    statusText.textContent =
        "Mengaktifkan GPS...";

    statusText.className =
        "status active";

    startButton.disabled = true;
    stopButton.disabled = false;

    watchID =
        navigator.geolocation.watchPosition(

        function(position) {

            const userLat =
                position.coords.latitude;

            const userLon =
                position.coords.longitude;

            currentLocation.textContent =
                `${userLat.toFixed(6)}, ${userLon.toFixed(6)}`;

            const distance =
                calculateDistance(
                    userLat,
                    userLon,
                    targetLat,
                    targetLon
                );

            distanceText.textContent =
                Math.round(distance) +
                " meter";

            if (
                distance <= alarmRadius &&
                !alarmActive
            ) {

                alarmActive = true;

                statusText.textContent =
                    "Tujuan Dekat!";

                statusText.className =
                    "status alarm";

                message.textContent =
                    `Kamu sudah mendekati ${destinationName}`;

                playAlarm();

                alert(
                    `Tujuan ${destinationName} sudah dekat!`
                );

            } else if (!alarmActive) {

                statusText.textContent =
                    "GPS Aktif";

                message.textContent =
                    `Pelacakan aktif menuju ${destinationName}`;
            }

        },

        function(error) {

            let errorText =
                "GPS bermasalah.";

            if (error.code === 1) {
                errorText =
                    "Izin lokasi ditolak.";
            }

            if (error.code === 2) {
                errorText =
                    "Lokasi tidak tersedia.";
            }

            if (error.code === 3) {
                errorText =
                    "GPS timeout.";
            }

            message.textContent =
                errorText;

            startButton.disabled = false;
            stopButton.disabled = true;
        },

        {
            enableHighAccuracy: true,
            timeout: 20000,
            maximumAge: 0
        }
    );
});

// ===================================
// HENTIKAN PELACAKAN
// ===================================

stopButton.addEventListener("click", () => {

    if (watchID !== null) {

        navigator.geolocation.clearWatch(
            watchID
        );

        watchID = null;
    }

    alarmActive = false;

    statusText.textContent =
        "Dihentikan";

    statusText.className =
        "status";

    distanceText.textContent =
        "-- meter";

    message.textContent =
        "Pelacakan dihentikan.";

    startButton.disabled = false;
    stopButton.disabled = true;
});

// ===================================
// FOOTER TAHUN OTOMATIS
// ===================================

const footerText =
    document.querySelector("footer p");

if (footerText) {

    footerText.textContent =
        `© ${new Date().getFullYear()} Travel Alarm. All Rights Reserved.`;
}